
import os
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import logging
import yfinance as yf
from ta.momentum import RSIIndicator
from ta.trend import MACD, ADXIndicator
import pandas as pd
import numpy as np
from scipy.stats import norm
from flask_cors import CORS
from retry import retry
import firebase_admin
from firebase_admin import auth, credentials
import threading
import stripe
import requests

# CONFIGURATION
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'shadowstrike-secret-2025')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///shadowstrike.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

if app.config['SQLALCHEMY_DATABASE_URI'].startswith('postgres://'):
    app.config['SQLALCHEMY_DATABASE_URI'] = app.config['SQLALCHEMY_DATABASE_URI'].replace('postgres://', 'postgresql://')

db = SQLAlchemy(app)
CORS(app)

try:
    cred = credentials.Certificate("path/to/your/firebase-adminsdk.json")
    firebase_admin.initialize_app(cred)
except Exception as e:
    logger.error(f"Firebase init error: {e}")

stripe.api_key = os.environ.get('STRIPE_SECRET_KEY', 'sk_test_demo_key')
app.config['STRIPE_PUBLIC_KEY'] = os.environ.get('STRIPE_PUBLIC_KEY', 'pk_test_demo_key')

BREVO_API_KEY = os.environ.get("BREVO_API_KEY")
BREVO_SENDER = {"name": "ShadowStrike Options", "email": "support@shadowstrike.com"}
BREVO_SMS_SENDER = "2154843692"

# Final portion: API routes, fetch functions, and Black-Scholes model
